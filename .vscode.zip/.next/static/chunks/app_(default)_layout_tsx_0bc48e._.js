(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(default)_layout_tsx_0bc48e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(default)_layout_tsx_0bc48e._.js",
  "chunks": [
    "static/chunks/node_modules_ca5886._.js",
    "static/chunks/_ff5427._.js",
    "static/chunks/node_modules_aos_dist_aos_941406.css"
  ],
  "source": "dynamic"
});
