(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(default)_page_tsx_1d3b50._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(default)_page_tsx_1d3b50._.js",
  "chunks": [
    "static/chunks/node_modules_10b745._.js",
    "static/chunks/_9d33d1._.js"
  ],
  "source": "dynamic"
});
