(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_d96937._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_d96937._.js",
  "chunks": [
    "static/chunks/[root of the server]__a65930._.css",
    "static/chunks/_b4b06d._.js"
  ],
  "source": "dynamic"
});
